import sys, pandas as pd
from preprocessing_pd import preprocessing_pd_report
from preprocessing_ct import preprocessing_ct_report

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.impute import SimpleImputer
import numpy as np
from sklearn.preprocessing import Normalizer
import matplotlib.pyplot as plt
from imblearn.over_sampling import SMOTE, RandomOverSampler

from sklearn.metrics import silhouette_score, adjusted_rand_score, confusion_matrix, multilabel_confusion_matrix
from sklearn.utils.multiclass import unique_labels
#import itertools


from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import KFold
from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2

from sklearn.metrics import mean_squared_error
from math import sqrt
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold
from sklearn.model_selection import LeaveOneOut
from sklearn.model_selection import LeavePOut
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import StratifiedKFold

from sklearn.model_selection import cross_val_predict
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
import sklearn.metrics as metrics
from sklearn.tree import DecisionTreeClassifier
import xgboost as xgb






def unsupervised_pd_report(data):
    print("Not ready")



def unsupervised_ct_report(data):
    print("Not ready")





def classification_pd_report(data):
    #using a 10-fold cross validation
    #Fazer a média das 3 medições
    data = data.groupby('id').mean().reset_index()

    y = data.pop('class').values
    df2 = pd.DataFrame(y, columns=['class'])
    transf = Normalizer().fit(data)
    norm_data = pd.DataFrame(transf.transform(data, copy=True), columns= data.columns)
    norm_data = pd.concat([norm_data, df2], axis=1)
    data = norm_data
    
    

    init_n_rows = str(data.shape[0])
    data = data.sort_values('id', ascending=True)
    data = data.groupby('id').mean().reset_index()
    final_n_rows = str(data.shape[0])

    unbal = data
    
    unbal = data
    target_count = unbal['class'].value_counts()
    
    min_class = target_count.idxmin()
    ind_min_class = target_count.index.get_loc(min_class)
    print(min_class)

    df_class_min = unbal[unbal['class'] == min_class]
    df_class_max = unbal[unbal['class'] != min_class]
    
    RANDOM_STATE = 42
    target_values_0 = target_count.values[ind_min_class]
    target_values_1 = target_count.values[1-ind_min_class]
    values = {'data': [target_values_0, target_values_1]}

    df_under = df_class_max.sample(len(df_class_min))
    values['UnderSample'] = [target_count.values[ind_min_class], len(df_under)]

    df_over = df_class_min.sample(len(df_class_max), replace=True)
    values['OverSample'] = [len(df_over), target_count.values[1-ind_min_class]]

    smote = SMOTE(ratio='minority', random_state=RANDOM_STATE)

    y = unbal.pop('class').values
    X = unbal.values
    smote_x, smote_y = smote.fit_sample(X, y)
    smote_target_count = pd.Series(smote_y).value_counts()

    df_SMOTE = pd.DataFrame(smote_x)
    df_SMOTE.columns = unbal.columns
    df_SMOTE['class'] = smote_y

    values['SMOTE'] = [smote_target_count.values[ind_min_class], smote_target_count.values[1-ind_min_class]]
    
    data = df_SMOTE

    data.to_csv(r'data.csv', index = False)

    #feature selection

    y = data.pop('class').values
    X = data.values
    
    X_norm = MinMaxScaler().fit_transform(X)

    X_norm = pd.DataFrame(X_norm, columns=data.columns)
    kbest = SelectKBest(chi2, k=100)
    X_new = kbest.fit_transform(X_norm, y)

    column_names = data.columns[kbest.get_support()]
    X_new = pd.DataFrame(X_norm, columns=column_names)

    df2 = pd.DataFrame(y, columns=['class'])
    data = pd.concat([X_new, df2], axis=1)

    print("2. Classifiers:\n ")

    labels = pd.unique(y)

   
    #X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=None, stratify=y)
    
    cv = KFold(n_splits=10, random_state=42, shuffle=False)
    
    y = data.pop('class').values
    X = data.values

    print("2.1 NB\n")
    print("a) Suggested parameterization: MultinomialNB with SMOTE and KBest feature selection")

    model = MultinomialNB()
    scoresNB = []
    y_predict_total =[]
    y_test_total =[]
    tn, fp, fn, tp = 0,0,0,0
    #print("Initial shape: "+str(X.shape))
    
    X = MinMaxScaler().fit_transform(X)
    X = pd.DataFrame(X)
    
    y_pred = cross_val_predict(model, X, y, cv=10)
    
    tn, fp, fn, tp = confusion_matrix(y, y_pred).ravel()
    
    acuNB = round(metrics.accuracy_score(y, y_pred),2)
    #acuNB = round((tp+tn)/(tp+tn+fp+fn),2)
    specificityNB = round(tn / (tn+fp),2)
    sensitivityNB = round(tp / (tp + fn),2)
    precisionNB = round(metrics.precision_score(y, y_pred),2)
    f1NB = round(metrics.f1_score(y, y_pred),2)
    
    
    
    #kfold = model_selection.KFold(n_splits=10, random_state=100)
    #model_kfold = MultinomialNB()
    #results_kfold = model_selection.cross_val_score(model_kfold, X, y, cv=kfold)
    #print(results_kfold)
    
    
    #for train_index, test_index in cv.split(X):
        
        #X_train, X_test, y_train, y_test = X[train_index], X[test_index], y[train_index], y[test_index]
        
        
        
        #model.fit(X_train, y_train)

        #y_predict = gaussNB.predict(X_test)

        #y_predict_total.extend(y_predict)
        #y_test_total.extend(y_train)

        #scoresNB.append(model.score(X_test, y_test))
        
    
    
    #print(np.mean(scoresNB))


    #y_predict = model.predict(X_test)

    #acu = accuracy_score(y_test, y_predict)
    
    #print("Accuracy:", round(acu,2))
    #tn, fp, fn, tp = confusion_matrix(y_test, y_predict).ravel()
    
    #print("Specificity: ", round(specificity,2))
    
    #print("Sensitivity: ", round(sensitivity,2))
    
    print("b) Confusion matrix: ")

    conf_mat = confusion_matrix(y, y_pred)
    print(conf_mat)
    
    print("2.2 kNN\n")
    print("a) Suggested parameterization: n_neighbors= 49, metric= euclidean, with SMOTE and KBest feature selection")


    model = KNeighborsClassifier(n_neighbors=49, metric='euclidean')
    scoresNB = []
    y_predict_total =[]
    y_test_total =[]
    tn, fp, fn, tp = 0,0,0,0
    
    X = MinMaxScaler().fit_transform(X)
    X = pd.DataFrame(X)
    
    y_pred = cross_val_predict(model, X, y, cv=10)
    
    tn, fp, fn, tp = confusion_matrix(y, y_pred).ravel()
    
    acukNN = round(metrics.accuracy_score(y, y_pred),2)
    #acuNB = round((tp+tn)/(tp+tn+fp+fn),2)
    specificitykNN = round(tn / (tn+fp),2)
    sensitivitykNN = round(tp / (tp + fn),2)
    precisionkNN = round(metrics.precision_score(y, y_pred),2)
    f1kNN = round(metrics.f1_score(y, y_pred),2)


    print("b) Confusion matrix: ")

    conf_mat = confusion_matrix(y, y_pred)
    print(conf_mat)

          
    print("2.3 DT\n")
    print("a) Suggested parameterization: max_depth=5, min_samples_split=0.1, min_samples_leaf=0.04, criterion=entropy with SMOTE and KBest feature selection")


    model = DecisionTreeClassifier(max_depth=5, min_samples_split=0.1, min_samples_leaf=0.04, criterion="entropy", random_state=1)
    scoresNB = []
    y_predict_total =[]
    y_test_total =[]
    tn, fp, fn, tp = 0,0,0,0
    
    X = MinMaxScaler().fit_transform(X)
    X = pd.DataFrame(X)
    
    y_pred = cross_val_predict(model, X, y, cv=10)
    
    tn, fp, fn, tp = confusion_matrix(y, y_pred).ravel()
    
    acuDT = round(metrics.accuracy_score(y, y_pred),2)
    #acuNB = round((tp+tn)/(tp+tn+fp+fn),2)
    specificityDT = round(tn / (tn+fp),2)
    sensitivityDT = round(tp / (tp + fn),2)
    precisionDT= round(metrics.precision_score(y, y_pred),2)
    f1DT = round(metrics.f1_score(y, y_pred),2)


    print("b) Confusion matrix: ")

    conf_mat = confusion_matrix(y, y_pred)
    print(conf_mat)
    
    
    print("2.5 RF\n")
    print("a) Suggested parameterization: learning_rate=0.1 with SMOTE and KBest feature selection")


    model = xgb.XGBClassifier(random_state=1,learning_rate=0.1)
    scoresNB = []
    y_predict_total =[]
    y_test_total =[]
    tn, fp, fn, tp = 0,0,0,0
    
    X = MinMaxScaler().fit_transform(X)
    X = pd.DataFrame(X)
    
    y_pred = cross_val_predict(model, X, y, cv=10)
    
    tn, fp, fn, tp = confusion_matrix(y, y_pred).ravel()
    
    acuRF = round(metrics.accuracy_score(y, y_pred),2)
    #acuNB = round((tp+tn)/(tp+tn+fp+fn),2)
    specificityRF = round(tn / (tn+fp),2)
    sensitivityRF = round(tp / (tp + fn),2)
    precisionRF= round(metrics.precision_score(y, y_pred),2)
    f1RF = round(metrics.f1_score(y, y_pred),2)


    print("b) Confusion matrix: ")

    conf_mat = confusion_matrix(y, y_pred)
    print(conf_mat)

          
    print("3. Comparative performance: NB | kNN | DT | RF ")

    print("3.1 Accuracy: ")
    
    print(str(acuNB)+" | "+ str(acukNN) +" | "+ str(acuDT)+" | "+ str(acuRF))

    # 0.76 | 0.81 | 0.56 | 0.90 3.2 

    print("3.2 Sensitivity: ")
    #  0.76 | 0.81 | 0.56 | 0.90 3.2 
    print(str(specificityNB)+" | "+ str(specificitykNN) +" | "+
          str(specificityDT)+" | "+ str(specificityRF))

    print("3.3 Sensitivity: ")
    #  0.76 | 0.81 | 0.56 | 0.90 3.2 
    
    print(str(sensitivityNB)+" | "+ str(sensitivitykNN) +" | "+
          str(sensitivityDT)+" | "+ str(sensitivityRF))
    
    print("3.5 Precision: ")
    #  0.76 | 0.81 | 0.56 | 0.90 3.2 
    
    print(str(precisionNB)+" | "+ str(precisionkNN) +" | "+
          str(precisionDT)+" | "+ str(precisionRF))
    print("3.5 Precision: ")
    #  0.76 | 0.81 | 0.56 | 0.90 3.2 
    
    print(str(precisionNB)+" | "+ str(precisionkNN) +" | "+
          str(precisionDT)+" | "+ str(precisionRF))

#from sklearn.metrics import multilabel_confusion_matrix
#multilabel_confusion_matrix(y_true, y_pred)






def classification_ct_report(data):
    y = data.pop('class').values
    df2 = pd.DataFrame(y, columns=['class'])
    transf = Normalizer().fit(data)
    norm_data = pd.DataFrame(transf.transform(data, copy=True), columns= data.columns)
    norm_data = pd.concat([norm_data, df2], axis=1)
    data = norm_data
    
    

    init_n_rows = str(data.shape[0])
    data = data.sort_values('id', ascending=True)
    data = data.groupby('id').mean().reset_index()
    final_n_rows = str(data.shape[0])

    unbal = data
    
    






def report(source, dataframe, task):
    task = task.strip()
    if task == "preprocessing":
        if source == "PD":
            return preprocessing_pd_report(dataframe)
        if source == "CT":
            return preprocessing_ct_report(dataframe)
    
    if task == "unsupervised":
        if source == "PD":
            return unsupervised_pd_report(dataframe)
        if source == "CT":
            return unsupervised_ct_report(dataframe)
    
    if task == "classification":
        if source == "PD":
            return classification_pd_report(dataframe)
        if source == "CT":
            return classification_ct_report(dataframe)
    

    

    return "Not yet available."




if __name__ == '__main__':

    '''A: read arguments'''
    args = sys.stdin.readline().rstrip('\n').split(' ')
    n, source, task = int(args[0]), args[1], args[2]
    
    '''B: read dataset'''
    data, header = [], sys.stdin.readline().rstrip('\r\n').split(',')
    
    for i in range(n-1):
        data.append(sys.stdin.readline().rstrip('\r\n').split(','))
    # Tudo forcado a ser float64 pois eram objetos
    dataframe = pd.DataFrame(data, columns=header, dtype=float)
    
    #dataframe = pd.read_csv('pd_speech_features.csv', sep=',')
    #dataframe = pd.read_csv('convAfterUndersampling.csv', sep=',')
    #task = "classification"
    #source = "CT"
    
    
    '''C: output results'''
    print(report(source, dataframe, task))


